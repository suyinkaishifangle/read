//
//  SFSafariViewController+TabbarSetting.m
//  SY
//
//  Created by 苏银 on 2019/6/18.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "SFSafariViewController+TabbarSetting.h"

@implementation SFSafariViewController (TabbarSetting)

- (instancetype)initSFWithURL:(NSURL *)URL
{
    self = [self initWithURL:URL];
    self.hidesBottomBarWhenPushed = YES;
    return self;
}
@end
