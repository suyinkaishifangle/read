//
//  PaidNewsCell.h
//  SY
//
//  Created by 苏银 on 2019/6/13.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PaidNewsModel.h"

@protocol PaidNewsCellDelegate <NSObject>

@optional
- (void)moreClicked;
- (void)paidNewsTappedByTag:(NSInteger)tag;

@end
@interface PaidNewsCell : UITableViewCell

@property (nonatomic, weak) id <PaidNewsCellDelegate> delegate;
@property (nonatomic, strong) PaidNewsModel *model;

+ (instancetype)cellWithTableView:(UITableView *)tableview PaidNewsModel:(PaidNewsModel *)model;

@end
