//
//  SYLoadingView.h
//  SY
//
//  Created by 苏银 on 2019/7/12.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SYLoadingView : UIView
//隐藏传入view中的loadingview
+ (BOOL)hideLoadingViewFromView:(UIView *)view;
//为传入view显示一个loadingview
+ (BOOL)showLoadingViewToView:(UIView *)view WithFrame:(CGRect)frame;

@end

NS_ASSUME_NONNULL_END
