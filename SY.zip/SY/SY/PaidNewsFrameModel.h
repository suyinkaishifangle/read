//
//  PaidNewsFrameModel.h
//  SY
//
//  Created by 苏银 on 2019/7/8.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PaidNewsFrameModel : NSObject

@property (nonatomic, assign) CGRect cellTitleFrame;
@property (nonatomic, assign) CGRect moreFrame;
@property (nonatomic, assign) CGRect backScrollViewFrame;
@property (nonatomic, strong) NSMutableArray *bg;
@property (nonatomic, strong) NSMutableArray *paidNewsViewFrames;
@property (nonatomic, strong) NSMutableArray *paidTitleFrames;
@property (nonatomic, strong) NSMutableArray *avatorFrames;
@property (nonatomic, strong) NSMutableArray *nicknameFrames;
@property (nonatomic, strong) NSMutableArray *updateInfoFrames;


//UIImageView *like = [[UIImageView alloc] init];
//[self.contentView addSubview:like];
//[like setImage:[UIImage imageNamed:@"like_20x17_"]];
//[like mas_makeConstraints:^(MASConstraintMaker *make) {
//    make.left.mas_equalTo(self.contentView.mas_left).with.offset(25.0);
//    make.top.mas_equalTo(self.rmdDescription.mas_bottom).with.offset(12.0);
//    make.width.mas_equalTo(14.0);
//    make.height.mas_equalTo(11.9);
//}];
//self.likeIcon = like;

+(instancetype)PaidNewsFrameModelWithCount:(NSInteger )count;

@end
