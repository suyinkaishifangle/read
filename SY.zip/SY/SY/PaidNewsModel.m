//
//  PaidNewsModel.m
//  SY
//
//  Created by 苏银 on 2019/6/13.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "PaidNewsModel.h"

@implementation PaidNewsModel

+ (instancetype)PaidNewsModelWithArr:(NSArray *)arr
{
    PaidNewsModel *model = [[self alloc] init];
    model.PaidNewsData = arr;
    model.paidNewsFrame = [PaidNewsFrameModel PaidNewsFrameModelWithCount:arr.count];
    model.cellHeight = SYScreenWidth * 0.8 + 60;
    return model;
}
@end
