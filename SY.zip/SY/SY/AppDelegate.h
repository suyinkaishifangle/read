//
//  AppDelegate.h
//  SY
//
//  Created by 苏银 on 2019/6/12.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYTabBarController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) SYTabBarController *tabbarVC;

@end

