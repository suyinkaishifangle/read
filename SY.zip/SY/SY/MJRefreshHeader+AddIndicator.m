//
//  MJRefreshHeader+AddIndicator.m
//  SY
//
//  Created by 苏银 on 2019/7/11.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "MJRefreshHeader+AddIndicator.h"

@implementation MJRefreshHeader (AddIndicator)

+ (instancetype)indicatorHeaderWithRefreshingTarget:(id)target refreshingAction:(SEL)action
{
    MJRefreshHeader *header =  [MJRefreshHeader headerWithRefreshingTarget:target refreshingAction:action];
    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    indicator.center = CGPointMake(SYScreenWidth/2, 40);
    [indicator startAnimating];
    [header addSubview:indicator];
    return header;
}
@end
