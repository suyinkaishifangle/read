//
//  MJRefreshHeader+AddIndicator.h
//  SY
//
//  Created by 苏银 on 2019/7/11.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface MJRefreshHeader (AddIndicator)
//简单自定义一个带有转动菊花的header
+ (instancetype)indicatorHeaderWithRefreshingTarget:(id)target refreshingAction:(SEL)action;

@end
