//
//  PaidNewsFrameModel.m
//  SY
//
//  Created by 苏银 on 2019/7/8.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "PaidNewsFrameModel.h"

@implementation PaidNewsFrameModel

+(instancetype)PaidNewsFrameModelWithCount:(NSInteger)count
{
    PaidNewsFrameModel *model = [[self alloc] init];
    
    float cellWidth = SYScreenWidth * 0.87;
    float cellHeight = SYScreenHeight * 0.71;
    model.cellTitleFrame = CGRectMake(25,  0, 100, 18);
    model.moreFrame = CGRectMake(SYScreenWidth - 75, 1, 40, 16);
    model.backScrollViewFrame = CGRectMake(0, 0, SYScreenWidth, SYScreenHeight);
    model.paidNewsViewFrames = [[NSMutableArray alloc] init];
    model.bg = [[NSMutableArray alloc] init];
    model.paidTitleFrames = [[NSMutableArray alloc] init];
    model.avatorFrames = [[NSMutableArray alloc] init];
    model.nicknameFrames = [[NSMutableArray alloc] init];
    model.updateInfoFrames = [[NSMutableArray alloc] init];

    for ( int i = 0; i < count; i++)
    {
        //背景
        NSValue *bg = [NSValue valueWithCGRect:CGRectMake(25 + (cellWidth + 15) * i, 73, cellWidth, cellHeight*1.07)];
        [model.bg addObject:bg];
        
        //书  图
        NSValue *paidNewsViewFrame = [NSValue valueWithCGRect:CGRectMake(15+cellWidth/3+ i * (cellWidth+15), 100 , cellWidth*0.4, cellHeight*0.4)];
        [model.paidNewsViewFrames addObject:paidNewsViewFrame];
        
        //头像
        NSValue *avatorFrame = [NSValue valueWithCGRect:CGRectMake(cellWidth*0.4/2 - 15, cellHeight - 110, 30, 30)];
        [model.avatorFrames addObject:avatorFrame];
        
        //作者
        NSValue *nicknameFrame = [NSValue valueWithCGRect:CGRectMake(0, cellHeight*0.58, cellWidth, 15)];
        [model.nicknameFrames addObject:nicknameFrame];
        
        //更新时间
        NSValue *updateInfoFrame = [NSValue valueWithCGRect:CGRectMake(15, cellHeight - 35, cellWidth - 30, 12)];
        [model.updateInfoFrames addObject:updateInfoFrame];
    }
    return model;
}

@end
