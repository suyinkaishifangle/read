//
//  NewsReadModel.m
//  SY
//
//  Created by 苏银 on 2019/6/15.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "NewsReadModel.h"

@implementation NewsReadModel

+ (instancetype)NewsReadModelWithDic:(NSDictionary *)dic
{
    NewsReadModel *model = [[self alloc] init];
    model.like_total = dic[@"like_total"];
    model.comment_total = dic[@"comment_total"];
    model.newsURL = dic[@"newsURL"];
    model.newsID = dic[@"newsID"];
    return model;
}
@end
