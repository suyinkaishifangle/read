//
//  HeaderView.h
//  SY
//
//  Created by 苏银 on 2019/6/12.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol HeaderViewDelegate <NSObject>

@optional
//导航右侧按钮的时间代理
- (void)BtnClicked;

@end

@interface HeaderView : UIView

@property (nonatomic, weak) id <HeaderViewDelegate> _Nullable delegate;
//button参数可为空的初始化方法
- (instancetype _Nullable )initWithTitle:(NSString *_Nullable)title Button:(nullable NSString *)button;
//scrollview的offset Y值变化时，视图作相应变化
- (void)viewScrolledByY:(float)Y;
//为messageView作特殊处理时调用
- (void)messageViewScrollBySmallY:(float)Y;
@end
