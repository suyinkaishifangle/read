//
//  FindCell.h
//  SY
//
//  Created by 苏银 on 2019/6/14.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FindModel.h"
@interface FindCell : UITableViewCell

@property (nonatomic, strong) FindModel *model;

+ (instancetype)FindCellWithTableView:(UITableView *)tableview FindModel:(FindModel *)model;

@end
