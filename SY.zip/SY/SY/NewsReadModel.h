//
//  NewsReadModel.h
//  SY
//
//  Created by 苏银 on 2019/6/15.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsReadModel : NSObject

@property (nonatomic, copy) NSString *like_total;
@property (nonatomic, copy) NSString *comment_total;
@property (nonatomic, copy) NSString *newsURL;
@property (nonatomic, copy) NSString *newsID;

+ (instancetype)NewsReadModelWithDic:(NSDictionary *)dic;

@end
