//
//  AdsModel.m
//  SY
//
//  Created by 苏银 on 2019/6/13.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "AdsModel.h"

@implementation AdsModel

+ (instancetype)AdsModelWithArr:(NSArray *)arr
{
    AdsModel *model = [[self alloc] init];
    model.AdsData = arr;
    model.cellHeight = (SYScreenWidth - 50) * 0.53125 + 40;
    return model;
}
@end
