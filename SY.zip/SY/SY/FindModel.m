//
//  FindModel.m
//  SY
//
//  Created by 苏银 on 2019/6/14.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "FindModel.h"

@implementation FindModel

+ (instancetype)FindModelWithDic:(NSDictionary *)dic
{
    FindModel *model = [[self alloc] init];
    model.title = dic[@"title"];
    model.banner = dic[@"banner"];
    return model;
}
@end
