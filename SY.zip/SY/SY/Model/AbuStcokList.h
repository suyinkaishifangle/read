//
//  AbuStcokList.h
//  阿布搜索Demo
//
//  Created by 阿布 on 17/3/15.
//  Copyright © 2017年 阿布. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AbuStcokList : NSObject
/**
 * 获取股票数据
 */
+ (NSMutableArray *)getStcokData;

@end
