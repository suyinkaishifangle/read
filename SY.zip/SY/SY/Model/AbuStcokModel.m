//
//  AbuStcokModel.m
//  阿布搜索Demo
//
//  Created by 阿布 on 17/3/15.
//  Copyright © 2017年 阿布. All rights reserved.
//

#import "AbuStcokModel.h"

@implementation AbuStcokModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
 
}

@end
