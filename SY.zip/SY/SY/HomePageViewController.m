//
//  HomePageViewController.m
//  SY
//
//  Created by 苏银 on 2019/6/12.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "HomePageViewController.h"
#import "HeaderView.h"
#import "PaidNewsCell.h"
#import "PaidNewsModel.h"
#import "TBActionSheet.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import "ClassedViewController.h"
#import "NewsReadModel.h"
#import "NewsReadController.h"
#import "MJRefreshHeader+AddIndicator.h"
#import "SYLoadingView.h"

#import "SFSafariViewController+TabbarSetting.h"

#import "AbuSearchView.h"

@interface HomePageViewController ()
<AbuSearchViewDelegate,
UIScrollViewDelegate,
HeaderViewDelegate,
UITableViewDelegate,
UITableViewDataSource,
TBActionSheetDelegate,
PaidNewsCellDelegate,
SFSafariViewControllerDelegate>
//顶部导航栏
//@property (nonatomic, strong) HeaderView *headerView;
//页面内容table
@property (nonatomic, strong) UITableView *newsTableView;
//页面容器scrollview
@property (nonatomic, strong) UIScrollView *backgroundScrollView;
//付费内容数据
@property (nonatomic, strong) NSMutableArray *paidNewsData;
//时间列表控件
@property (nonatomic, strong) TBActionSheet *actionSheet;

@property (nonatomic, strong) AbuSearchView * searchView;
/**
 * tableView
 */
//@property (nonatomic, strong) UITableView  * tableView;

/**
 * 数据源
 */
@property (nonatomic, strong) NSMutableArray * data;

@end

@implementation HomePageViewController

static NSString * ID = @"cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupView];
    [self setupData];
    [self setSearch];
 
    // Do any additional setup after loading the view.
}
- (void)setupData
{

//    为模拟网络获取数据时的延迟，这里手动设置延迟0.8s，否则loadingview一闪而过
    dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8/*延迟执行时间*/ * NSEC_PER_SEC));
    dispatch_after(delayTime, dispatch_get_main_queue(), ^{

        [self setpaidNewsData];
//        隐藏loadingview
        [SYLoadingView hideLoadingViewFromView:self.view];
    });
}

//设置主界面的数据
- (void)setpaidNewsData
{
    if(self.paidNewsData.count == 0 ){
        NSData *JSONDataPaid = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"paidNewsData" ofType:@"json"]];
        
        NSDictionary *paidDataDic = [NSJSONSerialization JSONObjectWithData:JSONDataPaid options:NSJSONReadingAllowFragments error:nil];
        NSMutableArray *paidNewsArray = paidDataDic[@"data"];
        
        PaidNewsModel *paidModel = [PaidNewsModel PaidNewsModelWithArr:paidNewsArray];
        [self.paidNewsData addObject:paidModel];
        [self.newsTableView reloadData];
    }
}
- (void)setupView
{
   // self.automaticallyAdjustsScrollViewInsets = NO;
    
    // 初始化loadingview
    CGRect loadingViewFrame = CGRectMake(0, 130, SYScreenWidth, SYScreenHeight - 130);
    [SYLoadingView showLoadingViewToView:self.view WithFrame:loadingViewFrame];
    
//    初始化背景scrollview
    UIScrollView *backScrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view insertSubview:backScrollView atIndex:0];
    self.backgroundScrollView = backScrollView;
    
//    初始化首页内容tableview
    UITableView *news = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    news.delegate = self;
    news.dataSource = self;
    news.sectionHeaderHeight = YES;
    news.backgroundColor = SYYinSe;
    news.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    [self.backgroundScrollView addSubview:news];
    news.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.newsTableView = news;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 76;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    return 10;
    
}



- (void)setSearch
{
    self.navigationController.navigationBar.translucent = NO;
    //[self.newsTableView addSubview:self.tableView];
    HS_WeakSelf(weakSelf);
    [self.newsTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.view);
    }];
    [self.backgroundScrollView addSubview:self.searchView];
}

- (TBActionSheet *)actionSheet
{
    if (_actionSheet == nil)
    {
        TBActionSheet *actionSheet = [[TBActionSheet alloc] initWithTitle:NULL message:NULL delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:NULL otherButtonTitles:@"分享", @"收藏", @"举报", nil];
        _actionSheet = actionSheet;
    }
    return _actionSheet;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //禁止左右移动
    scrollView.alwaysBounceHorizontal = YES;

}

#pragma mark - tableview delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.data.count > 0) {
        return 44;
    }
    else
    {
        PaidNewsModel *model = self.paidNewsData[0];
        return model.cellHeight;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.data.count>0){
        return self.data.count;
    }else{
        return self.paidNewsData.count;
    }
    

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.data.count > 0){
        AbuSearchViewCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];

        if (!cell) {
            cell = [[AbuSearchViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
            
        }
        if (indexPath.row < self.data.count) {
            cell.model = self.data[indexPath.row];
        }
        return cell;
        
    }else{
        PaidNewsModel *model = [self.paidNewsData objectAtIndex:0];
        PaidNewsCell *cell = [PaidNewsCell cellWithTableView:tableView PaidNewsModel:model];
        cell.delegate = self;
        return cell;
    }
}
    
    
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}


#pragma mark - NewsCell delegate
- (void)menuButtonClickedWithID:(NSString *)articleID
{
   // NSLog(@"文章cell中的菜单按钮被点击，文章id为：%@", articleID);
    [self.actionSheet show];
    
}

- (void)safariViewControllerDidFinish:(SFSafariViewController *)controller
{
    [self.navigationController popViewControllerAnimated:YES];
}




- (void)searchView:(AbuSearchView *)searchView resultStcokList:(NSMutableArray *)stcokList
{

        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            if (self.data.count) {
                [self.data removeAllObjects];
            }
            if (stcokList.count > 0) {
                [self.data addObjectsFromArray:stcokList];
            }else{
                [self.data addObjectsFromArray:stcokList];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.newsTableView reloadData];
            });
            
    });
    
}

-(BOOL)searchBarShouldBeginEditing:(AbuSearchView *)searchBar{
     //    NSLog(@"%s: Line-%d", __func__, __LINE__);
    return YES;
    
}
- (void)searchBarTextDidBeginEditing:(AbuSearchView *)searchBar{
    if(self.paidNewsData){
    [self.paidNewsData removeAllObjects];
    }
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);
    
}
- (BOOL)searchBarShouldEndEditing:(AbuSearchView *)searchBar{
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);
    return YES;
}
- (void)searchBarTextDidEndEditing:(AbuSearchView *)searchBar{
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);
    
}
- (void)searchBar:(AbuSearchView *)searchBar textDidChange:(NSString *)searchText{
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);
   // NSLog(@"---%@--%lu",searchText,(unsigned long)searchText.length);

    if(searchText.length == 0){
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setpaidNewsData];
        });
    }
}
- (BOOL)searchBar:(AbuSearchView *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);
    return YES;
    
}
- (void)searchBarSearchButtonClicked:(AbuSearchView *)searchBar{
    //    NSLog(@"%s: Line-%d", __func__, __LINE__);

    
}
- (void)searchBarCancelButtonClicked:(AbuSearchView *)searchBar{
    //NSLog(@"tuichu :%s: Line-%d", __func__, __LINE__);
    if (self.data.count > 0) {
        [self.data removeAllObjects];
    }
   
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setpaidNewsData];
        });
    
}


#pragma mark - 懒加载
- (AbuSearchView *)searchView
{
    if (!_searchView) {
        _searchView = [[AbuSearchView alloc]initWithFrame:CGRectMake(0, 10, self.view.frame.size.width, 45)];
        _searchView.delegate = self;
        _searchView.placeholder = @"代码/全拼";
        [_newsTableView registerClass:[AbuSearchViewCell class] forCellReuseIdentifier:ID];
    }
    return _searchView;
}

- (NSMutableArray *)paidNewsData
{
    if (_paidNewsData == nil)
    {
        _paidNewsData = [[NSMutableArray alloc] init];
    }
    return _paidNewsData;
}

- (NSMutableArray *)data
{
    if (!_data) {
        _data = [NSMutableArray array];
    }
    return _data;
}
@end
