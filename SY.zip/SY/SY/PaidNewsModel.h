//
//  PaidNewsModel.h
//  SY
//
//  Created by 苏银 on 2019/6/13.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PaidNewsFrameModel.h"

@interface PaidNewsModel : NSObject

@property (nonatomic, strong) NSArray *PaidNewsData;
@property (nonatomic, strong) PaidNewsFrameModel *paidNewsFrame;
@property (nonatomic, assign) CGFloat cellHeight;

+ (instancetype)PaidNewsModelWithArr:(NSArray *)arr;

@end
