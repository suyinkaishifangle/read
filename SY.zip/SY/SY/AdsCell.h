//
//  AdsCell.h
//  SY
//
//  Created by 苏银 on 2019/6/13.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdsModel.h"

@protocol AdsCellDelegate <NSObject>

@optional
- (void)adsCellTappedByTag:(NSInteger)tag;

@end

@interface AdsCell : UITableViewCell

@property (nonatomic, weak) id <AdsCellDelegate> delegate;
@property (nonatomic, strong) AdsModel *model;

+ (instancetype)cellWithTableview:(UITableView *)tableview AdsModel:(AdsModel *)model;

@end
