//
//  NewsReadController.h
//  SY
//
//  Created by 苏银 on 2019/6/15.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "SYSubViewController.h"
#import "NewsReadModel.h"
@interface NewsReadController : SYSubViewController

- (instancetype)initWithModel:(NewsReadModel *)model;

@end
