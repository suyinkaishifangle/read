//
//  SFSafariViewController+TabbarSetting.h
//  SY
//
//  Created by 苏银 on 2019/6/18.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <SafariServices/SafariServices.h>

@interface SFSafariViewController (TabbarSetting)

- (instancetype)initSFWithURL:(NSURL *)URL;

@end
