//
//  FindModel.h
//  SY
//
//  Created by 苏银 on 2019/6/14.
//  Copyright © 2019 苏银. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FindModel : NSObject

@property (nonatomic ,copy) NSString *title;
@property (nonatomic, copy) NSString *banner;

+ (instancetype)FindModelWithDic:(NSDictionary *)dic;

@end
