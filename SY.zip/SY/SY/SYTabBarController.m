//
//  SYTabBarController.m
//  SY
//
//  Created by 苏银 on 2019/6/12.
//  Copyright © 2019 苏银. All rights reserved.
//

#import "SYTabBarController.h"
#import "HomePageViewController.h"
#import "FoundViewController.h"
#import "MessageViewController.h"
#import "LoginPageViewController.h"
#import "SYNavController.h"

@interface SYTabBarController ()

@end

@implementation SYTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupTabbar];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setupTabbar
{
    
    //self.tabBar.translucent = YES;
    self.tabBar.alpha = 0.99;
    
    
    HomePageViewController *homePage = [[HomePageViewController alloc] init];
    [self addChildViewController:homePage withImage:[UIImage imageNamed:@"home_26x23_"] selectedImage:[UIImage imageNamed:@"home_pressed_26x23_"]];
    
    FoundViewController *foundPage = [[FoundViewController alloc] init];
    [self addChildViewController:foundPage withImage:[UIImage imageNamed:@"discover_18x24_"] selectedImage:[UIImage imageNamed:@"discover_pressed_18x24_"]];
    
    MessageViewController *messagePage = [[MessageViewController alloc] init];
    [self addChildViewController:messagePage withImage:[UIImage imageNamed:@"notification_20x24_"] selectedImage:[UIImage imageNamed:@"notification_pressed_20x24_"]];
    
    LoginPageViewController *loginPage = [[LoginPageViewController alloc] init];
    [self addChildViewController:loginPage withImage:[UIImage imageNamed:@"user_20x24_"] selectedImage:[UIImage imageNamed:@"user_pressed_20x24_"]];
}

- (void)addChildViewController:(UIViewController *)controller withImage:(UIImage *)image selectedImage:(UIImage *)selectImage
{
    SYNavController *nav = [[SYNavController alloc] initWithRootViewController:controller];
    [nav.tabBarItem setImage:image];
    [nav.tabBarItem setSelectedImage:selectImage];
    nav.tabBarItem.imageInsets = UIEdgeInsetsMake(5, 0,-5, 0);
    
    [self addChildViewController:nav];
    
}

@end
